<?php
// Direct boeken en betalen via Mollie, plus het onderhoud dat op de achtergrond loopt.
defined('PLEUNTJE') or exit;

require_once __DIR__ . '/gastmails.php';

const VASTHOUDEN_MINUTEN = 20;          // zo lang blijven datums vast terwijl iemand betaalt
const MOLLIE_API = 'https://api.mollie.com/v2';
const SITE_URL = 'https://boshuispleuntje.nl';

// ---------- Mollie ----------

function mollie_sleutel(): ?string
{
    $s = lees_json('instellingen.json', [])['mollie_sleutel'] ?? null;
    return is_string($s) && preg_match('/^(test|live)_[A-Za-z0-9]{20,}$/', $s) ? $s : null;
}

// 'live' = echte betalingen, 'test' = nep-betalingen, 'uit' = nog geen sleutel
function mollie_modus(): string
{
    $s = mollie_sleutel();
    if (!$s) return 'uit';
    return str_starts_with($s, 'live_') ? 'live' : 'test';
}

// Voor de tests op Claude's eigen computer kan Mollie worden nagebootst.
function mollie_verzoek(string $methode, string $pad, ?array $gegevens = null, ?string $sleutel = null): array
{
    if (isset($GLOBALS['MOLLIE_NEP']) && is_callable($GLOBALS['MOLLIE_NEP'])) {
        return ($GLOBALS['MOLLIE_NEP'])($methode, $pad, $gegevens);
    }
    $sleutel = $sleutel ?? mollie_sleutel();
    if (!$sleutel || !function_exists('curl_init')) return ['code' => 0, 'data' => null];
    $ch = curl_init(MOLLIE_API . $pad);
    $opties = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CUSTOMREQUEST => $methode,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $sleutel, 'Content-Type: application/json'],
    ];
    if ($gegevens !== null) $opties[CURLOPT_POSTFIELDS] = json_encode($gegevens);
    curl_setopt_array($ch, $opties);
    $antwoord = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'data' => $antwoord === false ? null : json_decode($antwoord, true)];
}

// ---------- Prijs (zelfde tarieven als op de site, uit tarieven.json) ----------

function tarieven(): ?array
{
    $pad = dirname(__DIR__, 2) . '/api-data/tarieven.json';
    $data = is_file($pad) ? json_decode((string) file_get_contents($pad), true) : null;
    return is_array($data) && isset($data['hoogseizoenDagen']) ? $data : null;
}

// Prijzen: wat Marjolein op /beheer heeft ingesteld, anders de standaardprijzen uit de code.
const PRIJS_GRENZEN = [
    'laagseizoen' => [10, 1000],
    'hoogseizoen' => [10, 1000],
    'schoonmaak' => [0, 500],
    'hond' => [0, 200],
    'toeristenbelasting' => [0, 20],
];

function prijzen(): array
{
    $t = tarieven() ?? [];
    $p = [];
    foreach (array_keys(PRIJS_GRENZEN) as $k) $p[$k] = isset($t[$k]) ? (float) $t[$k] : 0.0;
    $eigen = lees_json('instellingen.json', [])['prijzen'] ?? [];
    foreach (PRIJS_GRENZEN as $k => [$min, $max]) {
        if (isset($eigen[$k]) && is_numeric($eigen[$k]) && $eigen[$k] >= $min && $eigen[$k] <= $max) $p[$k] = (float) $eigen[$k];
    }
    return $p;
}

function bereken_prijs(string $aankomst, string $vertrek, int $personen, int $honden): ?array
{
    $t = tarieven();
    if (!$t || $vertrek > $t['tot']) return null;
    $t = array_merge($t, prijzen());
    $hoog = array_flip($t['hoogseizoenDagen']);
    $verblijf = 0;
    $n = 0;
    foreach (nachten($aankomst, $vertrek) as $nacht) {
        $verblijf += isset($hoog[$nacht]) ? $t['hoogseizoen'] : $t['laagseizoen'];
        $n++;
    }
    $hond = $honden > 0 ? $t['hond'] : 0;
    $belasting = round($n * $personen * $t['toeristenbelasting'], 2);
    $totaal = round($verblijf + $t['schoonmaak'] + $hond + $belasting, 2);
    return ['nachten' => $n, 'totaal' => $totaal, 'belasting' => $belasting];
}

function euro(float $bedrag): string
{
    return '€' . number_format($bedrag, 2, ',', '.');
}

// ---------- Boekingen ----------

function boekingen(): array
{
    return lees_json('boekingen.json', []);
}

function bewaar_boekingen(array $lijst): void
{
    schrijf_json('boekingen.json', array_values($lijst));
}

function zoek_boeking(string $id): ?array
{
    foreach (boekingen() as $b) if ($b['id'] === $id) return $b;
    return null;
}

function werk_boeking_bij(string $id, callable $wijzig): ?array
{
    return met_slot(function () use ($id, $wijzig) {
        $lijst = boekingen();
        foreach ($lijst as $i => $b) {
            if ($b['id'] === $id) {
                $lijst[$i] = $wijzig($b);
                bewaar_boekingen($lijst);
                return $lijst[$i];
            }
        }
        return null;
    });
}

$GLOBALS['MAANDEN_NL'] = ['januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
$GLOBALS['DAGEN_NL'] = ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'];

function datum_nl(string $iso): string
{
    $d = new DateTimeImmutable($iso);
    return $GLOBALS['DAGEN_NL'][(int) $d->format('w')] . ' ' . (int) $d->format('j') . ' ' . $GLOBALS['MAANDEN_NL'][(int) $d->format('n') - 1] . ' ' . $d->format('Y');
}

// Kijkt bij Mollie hoe het met de betaling van een boeking staat en handelt dat af.
// Wordt aangeroepen door Mollie zelf (webhook), door de terugkeerpagina en door het onderhoud.
function verwerk_betaling(string $boekingId): ?array
{
    $b = zoek_boeking($boekingId);
    if (!$b || empty($b['mollie_id']) || !in_array($b['status'], ['wacht', 'verlopen'], true)) return $b;

    // Een testbetaling kan alleen met de testsleutel worden opgevraagd, en een echte alleen met de live sleutel
    if (($b['mollie_sleutel_soort'] ?? '') !== mollie_modus()) return $b;
    $r = mollie_verzoek('GET', '/payments/' . rawurlencode($b['mollie_id']));
    $status = $r['data']['status'] ?? null;
    if (!$status) return $b;

    if ($status === 'paid' && !empty($b['proef'])) return rond_proefbetaling_af($boekingId, (string) ($r['data']['method'] ?? ''));
    if ($status === 'paid') return rond_betaalde_boeking_af($boekingId);

    if (in_array($status, ['canceled', 'expired', 'failed'], true)) {
        return werk_boeking_bij($boekingId, function ($b) use ($status) {
            $b['status'] = 'mislukt';
            $b['mollie_status'] = $status;
            return $b;
        });
    }
    // Nog open: als de vasthoudtijd voorbij is, de datums alvast weer vrijgeven
    if ($b['status'] === 'wacht' && ($b['vasthouden_tot'] ?? 0) <= time()) {
        return werk_boeking_bij($boekingId, function ($b) {
            $b['status'] = 'verlopen';
            return $b;
        });
    }
    return $b;
}

function rond_betaalde_boeking_af(string $boekingId): ?array
{
    $resultaat = met_slot(function () use ($boekingId) {
        $lijst = boekingen();
        $index = null;
        foreach ($lijst as $i => $b) if ($b['id'] === $boekingId) $index = $i;
        if ($index === null) return null;
        $b = $lijst[$index];
        if (!in_array($b['status'], ['wacht', 'verlopen'], true)) return ['boeking' => $b, 'nieuw' => false];

        // Zijn de datums intussen door iemand anders bezet? (alleen mogelijk als de betaling erg laat was)
        $bezet = array_flip(bezette_nachten($boekingId));
        $conflict = false;
        foreach (nachten($b['aankomst'], $b['vertrek']) as $n) if (isset($bezet[$n])) $conflict = true;

        $blokkades = blokkades();
        $blokkadeId = bin2hex(random_bytes(5));
        $blokkades[] = [
            'id' => $blokkadeId,
            'aankomst' => $b['aankomst'],
            'vertrek' => $b['vertrek'],
            'omschrijving' => $b['naam'] . ' (geboekt via boshuispleuntje.nl)',
            'boeking' => $b['id'],
            'aangemaakt' => date('Y-m-d H:i'),
        ];
        schrijf_json('blokkades.json', $blokkades);

        $b['status'] = 'betaald';
        $b['betaald_op'] = date('Y-m-d H:i');
        $b['blokkade'] = $blokkadeId;
        $b['conflict'] = $conflict;
        $lijst[$index] = $b;
        bewaar_boekingen($lijst);
        return ['boeking' => $b, 'nieuw' => true];
    });
    if (!$resultaat) return null;
    $b = $resultaat['boeking'];
    if ($resultaat['nieuw']) {
        if (($b['mollie_sleutel_soort'] ?? '') !== 'test') tel_gebeurtenis('geboekt');
        stuur_bevestiging($b);
        meld_marjolein_nieuwe_boeking($b);
    }
    return $b;
}

// Proefbetaling van €0,01 door Marjolein (knop op /beheer): zelfde weg als een gast, maar zonder
// blokkade, zonder gastmails en zonder toeristenbelasting. Alleen een mail aan Marjolein dat het werkt.
function rond_proefbetaling_af(string $boekingId, string $methode): ?array
{
    $nieuw = false;
    $b = werk_boeking_bij($boekingId, function ($b) use (&$nieuw) {
        if (!in_array($b['status'], ['wacht', 'verlopen'], true)) return $b;
        $nieuw = true;
        $b['status'] = 'proef_betaald';
        $b['betaald_op'] = date('Y-m-d H:i');
        return $b;
    });
    if ($b && $nieuw) {
        $methodes = ['ideal' => 'iDEAL', 'creditcard' => 'creditcard', 'bancontact' => 'Bancontact', 'paypal' => 'PayPal', 'applepay' => 'Apple Pay'];
        stuur_mail(MAIL_MARJOLEIN, 'Proefbetaling gelukt: online betalen werkt',
            "Je proefbetaling van €0,01 is gelukt" . ($methode ? ' (betaald met ' . ($methodes[$methode] ?? $methode) . ')' : '') . ".\n\n"
            . "Dit is getest:\n"
            . "- je site maakte de betaling aan bij Mollie\n"
            . "- Mollie gaf door dat er betaald is\n"
            . "- deze mail komt van je site\n\n"
            . "Gasten kunnen dus boeken en betalen op boshuispleuntje.nl.\n"
            . "Er is niets geblokkeerd en er zijn geen mails naar gasten gegaan. De €0,01 hoef je niet terug te betalen.\n");
    }
    return $b;
}

// ---------- Mails rond een boeking ----------

function stuur_bevestiging(array $b): void
{
    verstuur_gastmail('bevestiging', [
        'naam' => $b['naam'],
        'email' => $b['email'],
        'aankomst' => $b['aankomst'],
        'vertrek' => $b['vertrek'],
        'personen' => $b['personen'],
        'bedrag' => $b['bedrag'],
        'taal' => gast_taal($b['taal'] ?? ''),
    ]);
}

function meld_marjolein_nieuwe_boeking(array $b): void
{
    $tekst = "Er is een nieuwe boeking via boshuispleuntje.nl, en er is betaald.\n\n"
        . "Naam: {$b['naam']}\n"
        . "E-mail: {$b['email']}\n"
        . "Telefoon: " . ($b['telefoon'] ?: '-') . "\n"
        . "Aankomst: " . datum_nl($b['aankomst']) . "\n"
        . "Vertrek: " . datum_nl($b['vertrek']) . "\n"
        . "Personen: {$b['personen']}, honden: {$b['honden']}\n"
        . "Betaald: " . euro($b['bedrag']) . ($b['mollie_sleutel_soort'] === 'test' ? " (TESTBETALING, niet echt)" : '') . "\n"
        . "Bericht: " . ($b['bericht'] ?: '-') . "\n"
        . taal_regel($b['taal'] ?? 'nl') . "\n"
        . "De datums zijn automatisch geblokkeerd op boshuispleuntje.nl en gaan ook naar Airbnb.\n";
    if (!empty($b['conflict'])) {
        $tekst = "LET OP: deze datums waren intussen al bezet (waarschijnlijk via Airbnb). "
            . "Er is nu dubbel geboekt. Neem contact op met de gast en betaal terug via Mollie.\n\n" . $tekst;
    }
    stuur_mail(MAIL_MARJOLEIN, (!empty($b['conflict']) ? 'LET OP dubbel geboekt: ' : 'Nieuwe boeking: ') . $b['naam'] . ', ' . datum_nl($b['aankomst']), $tekst);
}

// Iemand begon met boeken en betalen op de site, maar betaalde niet (afgebroken, mislukt of verlopen).
// Marjolein krijgt dan één mail met de gegevens, zodat ze de gast eventueel zelf kan benaderen.
// We wachten 30 minuten na het begin: vaak probeert iemand het meteen opnieuw en betaalt dan wel.
// Geen mail als dezelfde gast (zelfde e-mail) of iemand anders dezelfde datums intussen wél betaald heeft.
function meld_niet_betaalde_pogingen(): void
{
    $lijst = boekingen();
    $teMelden = [];
    foreach ($lijst as $b) {
        if (!empty($b['niet_betaald_gemeld'])) continue;
        if (($b['mollie_sleutel_soort'] ?? '') === 'test' || !empty($b['proef'])) continue;
        // Proefjes met een nep-adres (zoals test@example.com) zijn geen echte gasten
        if (preg_match('/@(example\.(com|org|net|nl)|test\.(com|nl))$/i', $b['email'] ?? '')) continue;
        $begonnen = strtotime($b['aangemaakt']);
        $klaar = ($b['status'] === 'mislukt' && $begonnen < time() - 1800)
            // 'verlopen' = de datums zijn weer vrij, maar Mollie kan nog betalen; na een dag geven we het op
            || ($b['status'] === 'verlopen' && $begonnen < time() - 86400);
        if (!$klaar) continue;
        $teMelden[] = $b;
    }
    if (!$teMelden) return;

    foreach ($teMelden as $b) {
        // Eerst vastleggen, dan mailen: nooit dubbel
        werk_boeking_bij($b['id'], function ($x) { $x['niet_betaald_gemeld'] = date('Y-m-d H:i'); return $x; });

        $laterBetaald = false;
        foreach ($lijst as $a) {
            if ($a['status'] !== 'betaald' || $a['aangemaakt'] < $b['aangemaakt']) continue;
            if (strcasecmp($a['email'], $b['email']) === 0
                || ($a['aankomst'] < $b['vertrek'] && $a['vertrek'] > $b['aankomst'])) $laterBetaald = true;
        }
        if ($laterBetaald) continue;

        $bezet = array_flip(bezette_nachten());
        $nogVrij = true;
        foreach (nachten($b['aankomst'], $b['vertrek']) as $n) if (isset($bezet[$n])) $nogVrij = false;

        $reden = [
            'canceled' => 'de gast heeft het betalen zelf afgebroken',
            'failed' => 'de betaling is mislukt (bijvoorbeeld geweigerd door de bank)',
            'expired' => 'de gast heeft niet op tijd betaald',
        ][$b['mollie_status'] ?? ''] ?? 'de gast heeft niet betaald';

        $tekst = "Iemand wilde Pleuntje boeken via boshuispleuntje.nl, maar heeft NIET betaald.\n"
            . "Er is dus geen boeking en er is geen geld binnengekomen. Wat er gebeurde: {$reden}.\n\n"
            . "Naam: {$b['naam']}\n"
            . "E-mail: {$b['email']}\n"
            . "Telefoon: " . ($b['telefoon'] ?: '-') . "\n"
            . "Aankomst: " . datum_nl($b['aankomst']) . "\n"
            . "Vertrek: " . datum_nl($b['vertrek']) . "\n"
            . "Personen: {$b['personen']}, honden: {$b['honden']}\n"
            . "Bedrag: " . euro($b['bedrag'] ?? 0) . "\n"
            . "Bericht: " . (($b['bericht'] ?? '') ?: '-') . "\n"
            . taal_regel($b['taal'] ?? 'nl')
            . "Begonnen op: " . datum_nl(substr($b['aangemaakt'], 0, 10)) . ' om ' . substr($b['aangemaakt'], 11, 5) . "\n\n"
            . ($nogVrij
                ? "Deze datums zijn nog vrij. Je kunt de gast mailen of bellen om te vragen of het gelukt is.\n"
                : "Deze datums zijn intussen bezet (door een andere boeking).\n")
            . "Je hoeft verder niets te doen: de datums zijn niet geblokkeerd.\n";
        stuur_mail(MAIL_MARJOLEIN, 'Niet betaald: ' . $b['naam'] . ', ' . datum_nl($b['aankomst']), $tekst, $b['email']);
    }
}

// ---------- Reservekopie en privacycontrole ----------

// Alles wat nodig is om de agenda, boekingen en reviews terug te zetten, zonder wachtwoorden of sleutels
function reservekopie_inhoud(): array
{
    $instellingen = lees_json('instellingen.json', []);
    unset($instellingen['wachtwoord_hash'], $instellingen['mollie_sleutel'], $instellingen['airbnb_link'], $instellingen['review_geheim'], $instellingen['opzet_id'], $instellingen['prive_agenda_sleutel']);
    if (isset($instellingen['mails']['sleutelcode'])) $instellingen['mails']['sleutelcode'] = '(niet in de reservekopie)';
    return [
        'gemaakt' => date('Y-m-d H:i'),
        'site' => 'boshuispleuntje.nl',
        'blokkades' => blokkades(),
        'boekingen' => array_map(function ($b) { unset($b['sleutel']); return $b; }, boekingen()),
        'aanvragen' => lees_json('aanvragen.json', []),
        'reviews' => lees_json('reviews.json', []),
        'airbnb_notities' => lees_json('airbnb-notities.json', []),
        'instellingen' => $instellingen,
    ];
}

function stuur_reservekopie(): bool
{
    $data = reservekopie_inhoud();
    $aantalBoekingen = count(array_filter($data['boekingen'], fn($b) => $b['status'] === 'betaald'));
    $tekst = "Hoi Marjolein,\n\n"
        . "Hierbij de wekelijkse reservekopie van boshuispleuntje.nl. Je hoeft er niets mee te doen: "
        . "bewaar deze mail gewoon. Mocht er ooit iets misgaan met de website, dan kan Claude hiermee alles terugzetten.\n\n"
        . "In deze kopie:\n"
        . "- " . count($data['blokkades']) . " blokkades in de agenda\n"
        . "- $aantalBoekingen betaalde boekingen via de site\n"
        . "- " . count($data['reviews']) . " reviews\n\n"
        . "Wachtwoorden, de Mollie-sleutel en de code van het sleutelkluisje staan er bewust niet in.\n\n"
        . "Groetjes,\nboshuispleuntje.nl\n";
    return stuur_mail_met_bijlage(
        MAIL_RESERVEKOPIE,
        'Reservekopie boshuispleuntje.nl (' . date('j-n-Y') . ')',
        $tekst,
        'pleuntje-reservekopie-' . date('Y-m-d') . '.json',
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
    );
}

// Controleert of de gegevens van gasten niet via internet op te vragen zijn. Zo niet: meteen een mail.
function privacy_controle(bool $mailBijLek = true): array
{
    $map = realpath(gegevensmap());
    $site = realpath(dirname(__DIR__, 2));
    $binnenSite = $map && $site && str_starts_with($map, $site . DIRECTORY_SEPARATOR);
    $lek = [];
    if ($binnenSite) {
        $pad = str_replace(DIRECTORY_SEPARATOR, '/', substr($map, strlen($site)));
        foreach (['instellingen.json', 'boekingen.json', 'blokkades.json'] as $bestand) {
            $antwoord = haal_op(SITE_URL . $pad . '/' . $bestand);
            if ($antwoord !== null && trim($antwoord) !== '') $lek[] = $bestand;
        }
    }
    if ($lek && $mailBijLek) {
        stuur_mail(
            MAIL_MARJOLEIN,
            'LET OP: gegevens van boshuispleuntje.nl zijn mogelijk zichtbaar',
            "Hoi Marjolein,\n\nBij de dagelijkse controle bleek dat deze bestanden via internet op te vragen zijn: "
            . implode(', ', $lek) . ".\n\nVraag Claude om dit meteen op te lossen.\n"
        );
    }
    return ['map' => $binnenSite ? 'binnen de website (afgeschermd)' : 'buiten de website', 'lek' => $lek];
}

// ---------- Onderhoud: loopt op de achtergrond, hooguit eens per 5 minuten ----------

function onderhoud(bool $forceer = false): void
{
    try {
        $stempel = lees_json('onderhoud.json', ['laatst' => 0]);
        if (!$forceer && time() - ($stempel['laatst'] ?? 0) < 300) return;
        schrijf_json('onderhoud.json', ['laatst' => time()]);

        // Betalingen die nog openstaan nalopen (voor het geval Mollie's bericht niet aankwam)
        foreach (boekingen() as $b) {
            if (in_array($b['status'], ['wacht', 'verlopen'], true) && !empty($b['mollie_id'])
                && strtotime($b['aangemaakt']) > time() - 2 * 86400) {
                verwerk_betaling($b['id']);
            }
        }
        // Melding aan Marjolein als iemand begon met boeken maar niet betaalde
        meld_niet_betaalde_pogingen();

        // Mails aan gasten die nu aan de beurt zijn
        verstuur_geplande_mails();

        // Elke ochtend na 8:00 het bezoekersoverzicht van gisteren
        teller_ochtendmail();

        // Elke week een reservekopie naar Marjolein, elke dag een privacycontrole
        $stand = lees_json('reservekopie.json', ['laatst' => 0, 'controle' => 0]);
        if (time() - ($stand['laatst'] ?? 0) > 7 * 86400) {
            if (stuur_reservekopie()) $stand['laatst'] = time();
            schrijf_json('reservekopie.json', $stand);
        }
        if (time() - ($stand['controle'] ?? 0) > 86400) {
            $stand['controle'] = time();
            schrijf_json('reservekopie.json', $stand);
            privacy_controle();
        }

        // Oude mislukte pogingen opruimen (privacy)
        met_slot(function () {
            $grens = date('Y-m-d H:i', time() - 7 * 86400);
            $lijst = array_filter(boekingen(), fn($b) => !((in_array($b['status'], ['mislukt', 'verlopen'], true) || !empty($b['proef'])) && $b['aangemaakt'] < $grens));
            bewaar_boekingen($lijst);
        });
    } catch (Throwable $e) {
        // Onderhoud mag nooit de rest van de site laten mislukken
    }
}
