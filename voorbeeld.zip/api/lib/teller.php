<?php

// Bezoekersmails gaan naar Marjoleins Gmail (8 nov 2026, wens Marjolein; was info@boshuispleuntje.nl).
const MAIL_BEZOEK = 'mbothoff@gmail.com';
// 8 nov 2026 22:28: bezoekersmails UIT (wens Marjolein: "Uitzetten. Alles."). Weer aan? Zet op true. Tellen gaat door.
const BEZOEKERSMAIL_AAN = true; // 11 nov 2026 weer AAN (wens Marjolein)
// Sinds 11 nov 2026 vast om de 2 uur (wens Marjolein): mail pas als er minstens 2 nog niet gemailde uren zijn. false = elk uur.
const BEZOEKERSMAIL_PER_2_UUR = false; // 11 nov 2026 20:03: weer ELK UUR (wens Marjolein); true = om de 2 uur
// Bezoekersteller van boshuispleuntje.nl (25 okt 2026, wens Marjolein).
// Telt mensen en computers per dag en mailt elke ochtend om 8:00 een overzicht van gisteren naar info@.
// Privacy: er wordt geen IP-adres en geen cookie bewaard. Een bezoeker krijgt per dag een
// onherkenbare code (hash met een geheim dat elke dag wordt vervangen en daarna weggegooid),
// zodat je dezelfde persoon op één dag niet dubbel telt, maar niemand kunt volgen of herkennen.
defined('PLEUNTJE') or exit;

const TELLER_BEWAAR_DAGEN = 60;
const TELLER_MAIL_UUR = 8;

// Bekende computers: naam en waarom ze langskomen (in gewone taal voor Marjolein)
function teller_computers(): array
{
    return [
        ['/Googlebot|Google-InspectionTool|GoogleOther|Storebot-Google|AdsBot-Google|Mediapartners-Google/i', 'Google', 'leest je site door, zodat hij te vinden is in Google'],
        ['/Google-Calendar|Google-Calendar-Importer|Google Calendar/i', 'Google Agenda', 'haalt je boekingen op voor je eigen Google Agenda'],
        ['/bingbot|BingPreview|msnbot/i', 'Bing (Microsoft)', 'leest je site door voor de zoekmachine Bing'],
        ['/DuckDuckBot|DuckAssistBot/i', 'DuckDuckGo', 'leest je site door voor de zoekmachine DuckDuckGo'],
        ['/YandexBot|YandexImages/i', 'Yandex', 'Russische zoekmachine die je site doorleest'],
        ['/Baiduspider/i', 'Baidu', 'Chinese zoekmachine die je site doorleest'],
        ['/Applebot/i', 'Apple', 'leest je site voor Siri en zoeken op iPhone'],
        ['/Airbnb/i', 'Airbnb', 'haalt je agenda op, zodat bezette dagen ook in Airbnb dicht staan'],
        ['/facebookexternalhit|Facebot|meta-externalagent|meta-externalfetcher/i', 'Facebook/Instagram', 'maakt een voorbeeldje (foto en titel) als iemand je link deelt, of leest mee voor Meta'],
        ['/WhatsApp/i', 'WhatsApp', 'maakt een voorbeeldje als iemand je link in WhatsApp stuurt'],
        ['/Twitterbot|LinkedInBot|Pinterest|Slackbot|TelegramBot|Discordbot|SkypeUriPreview|Iframely|Embedly/i', 'Berichten-apps', 'maken een voorbeeldje als iemand je link deelt'],
        ['/GPTBot|ChatGPT-User|OAI-SearchBot|ClaudeBot|Claude-User|Claude-SearchBot|anthropic-ai|PerplexityBot|Perplexity-User|CCBot|Bytespider|Amazonbot|cohere-ai|Google-Extended|Diffbot|YouBot/i', 'AI-diensten', 'lezen je site om vragen van hun gebruikers te beantwoorden (zoals ChatGPT)'],
        ['/AhrefsBot|SemrushBot|MJ12bot|DotBot|DataForSeoBot|BLEXBot|SeznamBot|serpstatbot|PetalBot|Barkrowler|SEOkicks|Screaming Frog/i', 'Marketingbureaus', 'verzamelen gegevens over websites voor reclame- en zoekbureaus'],
        ['/UptimeRobot|Pingdom|StatusCake|Site24x7|Uptime/i', 'Bewakingsdiensten', 'kijken of je site in de lucht is'],
        ['/Mollie/i', 'Mollie', 'meldt dat een betaling is gelukt of veranderd'],
        ['/^curl\//i', 'Je eigen controle', 'kijkt elk uur of alles werkt en verstuurt op tijd de mails aan gasten'],
    ];
}

// Herkent een computer aan zijn naam. Geeft [naam, reden] of null voor een gewone bezoeker.
function teller_herken_computer(string $ua): ?array
{
    foreach (teller_computers() as [$patroon, $naam, $reden]) {
        if (preg_match($patroon, $ua)) return [$naam, $reden];
    }
    if ($ua === '' || preg_match('/bot\b|bot\/|crawl|spider|slurp|scan|fetch|python|java\/|wget|go-http|okhttp|axios|node-fetch|headless|phantom|lighthouse|httpclient|libwww|scrapy|feed/i', $ua)) {
        return ['Overige computers', 'onbekende programma\'s die het internet afstruinen (meestal onschuldig)'];
    }
    return null;
}

// Een teldag loopt van 8:00 tot 8:00 de volgende ochtend (26 okt 2026, wens Marjolein: 'om 8 uur schoon beginnen'),
// zodat de ochtendmail van 8:00 precies de 24 uur ervoor laat zien.
function teller_teldag(?int $t = null): string
{
    return date('Y-m-d', ($t ?? time()) - TELLER_MAIL_UUR * 3600);
}

// Telt een paar uurbestanden bij elkaar op (voor de nachtmail en de 2-uursmail).
function teller_samen(array $uren): array
{
    $nacht = ['mensen' => [], 'computers' => [], 'gebeurtenissen' => []];
    foreach ($uren as $k) {
        $u = lees_json(teller_bestand($k), []);
        foreach ($u['mensen'] ?? [] as $code => $m) {
            if (isset($nacht['mensen'][$code])) {
                $nacht['mensen'][$code]['paginas'] += $m['paginas'] ?? 0;
                if (!empty($m['boekvenster'])) $nacht['mensen'][$code]['boekvenster'] = true;
            } else {
                $nacht['mensen'][$code] = $m;
            }
        }
        foreach ($u['computers'] ?? [] as $naam => $c) {
            $nacht['computers'][$naam] = ['aantal' => ($nacht['computers'][$naam]['aantal'] ?? 0) + $c['aantal'], 'reden' => $c['reden']];
        }
        foreach ($u['gebeurtenissen'] ?? [] as $soort => $n) $nacht['gebeurtenissen'][$soort] = ($nacht['gebeurtenissen'][$soort] ?? 0) + $n;
    }
    return $nacht;
}

function teller_bestand(string $dag): string
{
    return 'teller-' . $dag . '.json';
}

// Werkt de telling van vandaag bij, met een eigen slot (los van boekingen, zodat het nooit iets ophoudt)
function teller_bij(callable $wijzig, ?string $dag = null): void
{
    try {
        $sleutels = [$dag ?? teller_teldag()];
        // Ook per los uur (26 okt 2026, wens Marjolein: elk uur een mail, vanaf nul, niet opgeteld)
        if ($dag === null) $sleutels[] = date('Y-m-d-H');
        $slot = @fopen(gegevensmap() . '/.slot-teller', 'c');
        if (!$slot) return;
        flock($slot, LOCK_EX);
        try {
            foreach ($sleutels as $sleutel) {
                $data = lees_json(teller_bestand($sleutel), []);
                $data += ['mensen' => [], 'computers' => [], 'gebeurtenissen' => []];
                $data = $wijzig($data);
                schrijf_json(teller_bestand($sleutel), $data);
            }
        } finally {
            flock($slot, LOCK_UN);
            fclose($slot);
        }
    } catch (Throwable $e) {
        // Tellen mag nooit iets anders laten mislukken
    }
}

// Onherkenbare code voor een bezoeker, alleen geldig op deze dag
function teller_bezoekerscode(): string
{
    $dag = teller_teldag();
    $zout = lees_json('teller-zout.json', []);
    if (($zout['dag'] ?? '') !== $dag) {
        $zout = ['dag' => $dag, 'geheim' => bin2hex(random_bytes(16))];
        try { schrijf_json('teller-zout.json', $zout); } catch (Throwable $e) {}
    }
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    return substr(hash('sha256', $zout['geheim'] . '|' . $ip . '|' . $ua), 0, 16);
}

function teller_apparaat(string $ua): string
{
    if (preg_match('/iPad|Tablet|Android(?!.*Mobile)/i', $ua)) return 'tablet';
    if (preg_match('/Mobi|iPhone|Android/i', $ua)) return 'telefoon';
    return 'computer';
}

// Waar kwam iemand vandaan (op basis van de vorige pagina)
function teller_bron(string $verwijzing): string
{
    $host = strtolower((string)parse_url($verwijzing, PHP_URL_HOST));
    $host = preg_replace('/^(www|m|l|lm)\./', '', $host);
    if ($host === '' || str_ends_with($host, 'boshuispleuntje.nl')) return 'direct';
    if (preg_match('/(^|\.)google\./', $host)) return 'Google';
    if (preg_match('/(^|\.)airbnb\./', $host)) return 'Airbnb';
    if (preg_match('/facebook\.com|fb\.com|instagram\.com/', $host)) return 'Facebook/Instagram';
    if (preg_match('/bing\.com/', $host)) return 'Bing';
    if (preg_match('/duckduckgo\.com/', $host)) return 'DuckDuckGo';
    if (preg_match('/whatsapp/', $host)) return 'WhatsApp';
    if (preg_match('/mail\.|outlook|gmail/', $host)) return 'e-mail';
    return $host;
}

// Een computer telt mee (door de server zelf aangeroepen, bijv. bij agenda.php of een pagina)
// $anders: wie het waarschijnlijk is als de naam niet herkend wordt (bijv. bij de agendalink voor Airbnb)
function tel_computer(?string $ua = null, ?array $anders = null): bool
{
    $ua = $ua ?? (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    $herkend = teller_herken_computer($ua);
    if ($anders && (!$herkend || $herkend[0] === 'Overige computers')) {
        // Een gewone browser op deze link is meestal Marjolein zelf: niet tellen
        if (!$herkend && preg_match('/Mozilla\/5\.0 \((iPhone|iPad|Macintosh|Windows|Linux; Android)/', $ua) && !preg_match('/Google/i', $ua)) return false;
        $herkend = $anders;
    }
    if (!$herkend) return false;
    [$naam, $reden] = $herkend;
    teller_bij(function ($d) use ($naam, $reden) {
        $d['computers'][$naam] = ['aantal' => ($d['computers'][$naam]['aantal'] ?? 0) + 1, 'reden' => $reden];
        return $d;
    });
    return true;
}

// Een gebeurtenis zonder persoon erbij (betaling gestart, geboekt, aanvraag, vraag)
function tel_gebeurtenis(string $soort): void
{
    teller_bij(function ($d) use ($soort) {
        $d['gebeurtenissen'][$soort] = ($d['gebeurtenissen'][$soort] ?? 0) + 1;
        return $d;
    });
}

// Een bezoek van een mens (via het stukje op elke pagina)
function tel_bezoek(string $soort, string $pagina, string $verwijzing, string $taal): void
{
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (tel_computer($ua)) return;
    $code = teller_bezoekerscode();
    $apparaat = teller_apparaat($ua);
    $bron = teller_bron($verwijzing);
    $taal = in_array($taal, ['nl', 'de', 'en', 'fr'], true) ? $taal : 'nl';
    $pagina = substr(preg_replace('/[^a-z0-9\/_-]/i', '', $pagina), 0, 60) ?: '/';
    teller_bij(function ($d) use ($code, $soort, $pagina, $bron, $taal, $apparaat) {
        $m = $d['mensen'][$code] ?? ['paginas' => 0, 'bron' => $bron, 'taal' => $taal, 'apparaat' => $apparaat, 'gezien' => []];
        if ($soort === 'pagina') {
            $m['paginas']++;
            if (count($m['gezien']) < 15 && !in_array($pagina, $m['gezien'], true)) $m['gezien'][] = $pagina;
            if ($m['bron'] === 'direct' && $bron !== 'direct') $m['bron'] = $bron;
        } elseif ($soort === 'boekvenster') {
            $m['boekvenster'] = true;
        }
        $d['mensen'][$code] = $m;
        return $d;
    });
}

function teller_nl_dag(string $dag): string
{
    $dagen = ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'];
    $maanden = ['', 'januari', 'februari', 'maart', 'april', 'mei', 'juni', 'juli', 'augustus', 'september', 'oktober', 'november', 'december'];
    $t = strtotime($dag . ' 12:00');
    return $dagen[(int)date('w', $t)] . ' ' . (int)date('j', $t) . ' ' . $maanden[(int)date('n', $t)];
}

function teller_lijstje(array $telling): string
{
    arsort($telling);
    $delen = [];
    foreach ($telling as $naam => $aantal) $delen[] = $naam . ' ' . $aantal;
    return implode(' · ', $delen);
}

// Was er iemand? (een mens, of een boeking/aanvraag/vraag). Alleen computers telt niet.
function teller_iemand(array $d): bool
{
    return !empty($d['mensen']) || !empty($d['gebeurtenissen']);
}

// Het ochtendmailtje over één dag. Geeft [onderwerp, tekst].
function teller_rapport(string $dag, ?string $titel = null, ?array $data = null): array
{
    $d = $data ?? lees_json(teller_bestand($dag), []);
    $mensen = $d['mensen'] ?? [];
    $computers = $d['computers'] ?? [];
    $g = $d['gebeurtenissen'] ?? [];
    $aantal = count($mensen);
    $paginas = array_sum(array_map(fn($m) => $m['paginas'] ?? 0, $mensen));
    $kalender = count(array_filter($mensen, fn($m) => !empty($m['boekvenster'])));
    $dagNaam = $titel ?? teller_nl_dag($dag);

    $r = [];
    $r[] = $titel !== null
        ? 'Bezoek aan boshuispleuntje.nl op ' . $titel
        : 'Bezoek aan boshuispleuntje.nl van ' . $dagNaam . ' 8:00 tot ' . teller_nl_dag(date('Y-m-d', strtotime($dag . ' 12:00 +1 day'))) . ' 8:00';
    $r[] = '';

    // Extra melding bovenaan als er geboekt, aangevraagd of gevraagd is
    $extra = [];
    if (!empty($g['geboekt'])) $extra[] = ($g['geboekt'] == 1 ? 'Er is 1 keer' : 'Er is ' . $g['geboekt'] . ' keer') . ' geboekt én betaald via je site!';
    if (!empty($g['betaling_gestart'])) $extra[] = $g['betaling_gestart'] . ($g['betaling_gestart'] == 1 ? ' bezoeker begon' : ' bezoekers begonnen') . ' met betalen.';
    if (!empty($g['aanvraag'])) $extra[] = $g['aanvraag'] . ($g['aanvraag'] == 1 ? ' boekingsaanvraag' : ' boekingsaanvragen') . ' ontvangen.';
    if (!empty($g['vraag'])) $extra[] = $g['vraag'] . ($g['vraag'] == 1 ? ' vraag' : ' vragen') . ' gesteld via "Een vraag?".';
    if ($extra) {
        $r[] = 'BOEKEN:';
        foreach ($extra as $e) $r[] = '- ' . $e;
        $r[] = '';
    }

    $r[] = 'MENSEN:';
    if ($aantal === 0) {
        $r[] = '- Er is niemand op je site geweest.';
    } else {
        $r[] = '- ' . ($aantal === 1 ? '1 persoon bekeek' : $aantal . ' mensen bekeken') . ' je site (samen ' . $paginas . ($paginas === 1 ? ' pagina' : ' pagina\'s') . ').';
        $r[] = '- ' . ($kalender === 0 ? 'Niemand opende' : ($kalender === 1 ? '1 persoon opende' : $kalender . ' mensen openden')) . ' het boekingsvenster met de kalender.';
        $bronnen = [];
        $talen = [];
        $apparaten = [];
        $taalNaam = ['nl' => 'Nederlands', 'de' => 'Duits', 'en' => 'Engels', 'fr' => 'Frans'];
        foreach ($mensen as $m) {
            $bronnen[$m['bron']] = ($bronnen[$m['bron']] ?? 0) + 1;
            $t = $taalNaam[$m['taal']] ?? $m['taal'];
            $talen[$t] = ($talen[$t] ?? 0) + 1;
            $apparaten[$m['apparaat']] = ($apparaten[$m['apparaat']] ?? 0) + 1;
        }
        $r[] = '';
        $r[] = 'HOE HEBBEN ZE JE GEVONDEN?';
        arsort($bronnen);
        $uitleg = [
            'Google' => 'via Google (ze zochten iets en klikten op jouw site)',
            'Airbnb' => 'via Airbnb (de link naar je site)',
            'Facebook/Instagram' => 'via Facebook of Instagram',
            'Bing' => 'via de zoekmachine Bing',
            'DuckDuckGo' => 'via de zoekmachine DuckDuckGo',
            'WhatsApp' => 'via een link in WhatsApp',
            'e-mail' => 'via een link in een e-mail',
            'direct' => 'direct: adres zelf getypt, of een link uit een app of mail (welke is niet te zien)',
        ];
        foreach ($bronnen as $bron => $n) {
            $r[] = '- ' . $n . ' ' . ($n === 1 ? 'persoon' : 'mensen') . ' ' . ($uitleg[$bron] ?? 'via de website ' . $bron);
        }
        $r[] = '(Waar ze in Google precies op zochten, geeft Google niet door.)';
        $r[] = '';
        $r[] = 'VERDER:';
        $r[] = '- Taal: ' . teller_lijstje($talen);
        $r[] = '- Apparaat: ' . teller_lijstje($apparaten);
    }
    $r[] = '';

    $r[] = 'COMPUTERS (automatische bezoekers, geen mensen):';
    if (!$computers) {
        $r[] = '- Geen.';
    } else {
        uasort($computers, fn($a, $b) => $b['aantal'] <=> $a['aantal']);
        foreach ($computers as $naam => $c) {
            $r[] = '- ' . $naam . ' (' . $c['aantal'] . ' keer): ' . $c['reden'] . '.';
        }
    }
    $r[] = '';
    $r[] = 'Jouw eigen bezoeken tellen niet mee. Iemand die op telefoon én iPad kijkt, telt als twee mensen. Namen of adressen van bezoekers worden niet bewaard.';

    $onderwerp = 'Bezoek Pleuntje ' . $dagNaam . ': ' . ($aantal === 1 ? '1 persoon' : $aantal . ' mensen')
        . (!empty($g['geboekt']) ? ' (er is geboekt!)' : ($kalender ? ', ' . $kalender . ' in de kalender' : ''));
    return [$onderwerp, implode("\n", $r)];
}

// Wordt vanuit onderhoud() aangeroepen: stuurt elk uur het rapport van het uur ervoor en ruimt oude tellingen op
function teller_ochtendmail(): void
{
    try {
        $stand = lees_json('teller-stand.json', null);
        if ($stand === null) {
            $stand = ['gemaild' => '', 'begonnen' => date('Y-m-d')];
            schrijf_json('teller-stand.json', $stand);
        }
        // Eenmalig schoon begonnen op maandag 26 okt 2026 (wens Marjolein): alles van vóór dat moment weg,
        // ook de losse uurtellingen van zondag 25 okt. De volgende mail (di 27 okt 8:00) telt vanaf dit moment.
        if (empty($stand['schoon_begonnen'])) {
            foreach (glob(gegevensmap() . '/teller-20*.json') ?: [] as $pad) @unlink($pad);
            $stand['schoon_begonnen'] = date('Y-m-d H:i');
            $stand['gemaild'] = date('Y-m-d', strtotime('-1 day'));
            schrijf_json('teller-stand.json', $stand);
        }
        // Sinds 26 okt 2026 (wens Marjolein): elk uur een mail over alleen het uur ervoor, vanaf nul,
        // niet opgeteld bij eerdere uren. De ochtendmail over de hele dag is daarmee vervallen.
        $vorigUur = time() - 3600;
        $sleutel = date('Y-m-d-H', $vorigUur);
        if (empty($stand['uur_gemaild'])) {
            // Net aangezet: het lopende uur wordt het eerste uur dat gemaild wordt
            $stand['uur_gemaild'] = $sleutel;
            $stand['uur_begonnen'] = date('Y-m-d H:i');
            schrijf_json('teller-stand.json', $stand);
        } elseif ((int)date('G') === 7 && $stand['uur_gemaild'] < $sleutel) {
            // 's Nachts geen mail (26 okt 2026, wens Marjolein: niet tussen 23:00 en 7:00).
            // Om 7:00 één mail over de hele nacht, van 22:00 tot 7:00.
            $uren = [];
            // Ook de avonduren die nog niet gemaild zijn gaan mee (hooguit 24 uur terug)
            $g = $stand['uur_gemaild'];
            $begin = min(strtotime(date('Y-m-d 22:00', strtotime('-1 day'))), strtotime(substr($g, 0, 10) . ' ' . substr($g, 11) . ':00') + 3600);
            $begin = max($begin, $vorigUur - 23 * 3600);
            for ($t = $begin; $t < strtotime(date('Y-m-d 07:00')); $t += 3600) $uren[] = date('Y-m-d-H', $t);
            $nacht = teller_samen($uren);
            $titel = 'de nacht van ' . teller_nl_dag(date('Y-m-d', strtotime('-1 day'))) . ' op ' . teller_nl_dag(date('Y-m-d')) . ', ' . date('H:00', $begin) . ' tot 07:00';
            [$onderwerp, $tekst] = teller_rapport($sleutel, $titel, $nacht);
            $onderwerp = 'Bezoek Pleuntje nacht ' . date('H:00', $begin) . '-07:00: ' . substr($onderwerp, strlen('Bezoek Pleuntje ' . $titel . ': '));
            $voor = "De hele nacht samen in één mail (tussen 23:00 en 7:00 krijg je geen mail).";
            // Niemand geweest (alleen computers of niets)? Dan geen mail (30 okt 2026, wens Marjolein)
            if (!BEZOEKERSMAIL_AAN || !teller_iemand($nacht) || stuur_mail(MAIL_BEZOEK, $onderwerp, $voor . "\n\n" . $tekst)) {
                $stand['uur_gemaild'] = $sleutel;
                schrijf_json('teller-stand.json', $stand);
            }
        } elseif ((int)date('G') >= 8 && (int)date('G') <= 22 && $stand['uur_gemaild'] < $sleutel) {
            // Alle uren die nog niet gemaild zijn (hooguit 24 uur terug), zodat niets wordt overgeslagen,
            // ook niet als GitHub de server een paar uur niet aanport (11 nov 2026).
            $g = $stand['uur_gemaild'];
            $begin = max(strtotime(substr($g, 0, 10) . ' ' . substr($g, 11) . ':00') + 3600, $vorigUur - 23 * 3600);
            $uren = [];
            for ($t = $begin; $t <= $vorigUur; $t += 3600) $uren[] = date('Y-m-d-H', $t);
            if (!$uren) $uren = [$sleutel];
            if (BEZOEKERSMAIL_PER_2_UUR && count($uren) < 2) return; // nog even wachten tot er 2 uur zijn
            $eerste = strtotime(substr($uren[0], 0, 10) . ' ' . substr($uren[0], 11) . ':00');
            $van = date('H:00', $eerste);
            $tot = date('H:00');
            $titel = teller_nl_dag(date('Y-m-d', $eerste)) . ', ' . $van . ' tot ' . $tot;
            $samen = teller_samen($uren);
            [$onderwerp, $tekst] = teller_rapport($sleutel, $titel, $samen);
            $onderwerp = 'Bezoek Pleuntje ' . $van . '-' . $tot . ': ' . substr($onderwerp, strlen('Bezoek Pleuntje ' . $titel . ': '));
            $voor = count($uren) > 1
                ? 'De ' . count($uren) . ' uur van ' . $van . ' tot ' . $tot . ' samen.'
                : 'Alleen het uur van ' . $van . ' tot ' . $tot . '.';
            if (substr($stand['uur_begonnen'] ?? '', 0, 13) === date('Y-m-d H', $vorigUur)) {
                $voor .= ' Dit eerste uur telt pas vanaf ' . substr($stand['uur_begonnen'], 11) . '.';
            }
            if (!BEZOEKERSMAIL_AAN || !teller_iemand($samen) || stuur_mail(MAIL_BEZOEK, $onderwerp, $voor . "\n\n" . $tekst)) {
                $stand['uur_gemaild'] = $sleutel;
                schrijf_json('teller-stand.json', $stand);
            }
        }
        // Oude tellingen weg (privacy en opruimen), per dag en per uur
        foreach (glob(gegevensmap() . '/teller-20*.json') ?: [] as $pad) {
            if (preg_match('/teller-(\d{4}-\d{2}-\d{2})(-\d{2})?\.json$/', $pad, $m) && $m[1] < date('Y-m-d', strtotime('-' . TELLER_BEWAAR_DAGEN . ' days'))) @unlink($pad);
        }
    } catch (Throwable $e) {
        // Nooit iets anders laten mislukken
    }
}
